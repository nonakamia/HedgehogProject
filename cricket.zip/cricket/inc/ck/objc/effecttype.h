// Copyright 2016 Cricket Technology
// www.crickettechnology.com

#import "ck/effecttype.h"


